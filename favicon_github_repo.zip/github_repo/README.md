# Favicon Downloader

575 spor & casino sitesinin favicon'larını otomatik indirir.

## Nasıl çalıştırılır?

1. Bu repoyu GitHub'a yükle
2. **Actions** sekmesine git
3. **Favicon Downloader** workflow'unu seç
4. **Run workflow** butonuna tıkla
5. ~5 dakika bekle
6. Biten workflow'a tıkla → **favicons** artifact'ini indir (ZIP)

Hepsi bu kadar.
